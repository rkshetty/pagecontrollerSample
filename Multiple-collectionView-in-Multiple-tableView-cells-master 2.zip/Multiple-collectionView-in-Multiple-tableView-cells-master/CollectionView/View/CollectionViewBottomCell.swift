//
//  CollectionViewBottomCell.swift
//  CollectionView
//
//  Created by Narayana rao Kandregula on 13/05/19.
//  Copyright © 2019 TCS. All rights reserved.
//
import UIKit

class CollectionViewBottomCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
   @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
